import test from 'node:test';
import assert from 'node:assert/strict';
import {comparisonBlock} from '../src/lib/shared-content-preview.js';

test('comparison identities preserve native document types, prose and semantic keys',()=>{
 const block={id:'q',type:'question',flow:{fragment:1},content:{id:'root',prompt:{format:'maths-editor-document-v1',blocks:[{id:'table',type:'table',rows:[[{id:'cell',type:'cell',blocks:[{id:'p',type:'paragraph',inlines:[{type:'text',text:'table'}]}]}]]}]},representations:{table:'table'},questionDiagrams:[{id:'diagram',format:'svg'},{id:'overlay',overlayOf:'diagram'}],answer:{short:'table',targetIds:['cell']}},presentation:{layoutOverrides:{diagramWidths:{diagram:30}}}};
 const a=comparisonBlock(block,'left-student-'),b=comparisonBlock(block,'left-worked-');
 assert.equal(a.content.prompt.blocks[0].id,'left-student-table');
 assert.equal(a.content.prompt.blocks[0].type,'table');
 assert.equal(a.content.prompt.blocks[0].rows[0][0].blocks[0].inlines[0].text,'table');
 assert.deepEqual(a.content.representations,{table:'table'});
 assert.equal(a.content.answer.short,'table');
 assert.deepEqual(a.content.answer.targetIds,['left-student-cell']);
 assert.equal(a.content.questionDiagrams[1].overlayOf,'left-student-diagram');
 assert.deepEqual(a.presentation.layoutOverrides.diagramWidths,{'left-student-diagram':30});
 assert.notEqual(a.id,b.id);assert.equal(a.flow,undefined);
 assert.equal(block.id,'q');assert.equal(block.flow.fragment,1);
});
