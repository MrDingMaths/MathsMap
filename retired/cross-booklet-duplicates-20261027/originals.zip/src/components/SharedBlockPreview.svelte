<script>
  import {setContext} from 'svelte';
  import {comparisonBlock} from '../lib/shared-content-preview.js';
  import TranscribedBookletPage from './TranscribedBookletPage.svelte';
  import PracticeQuestionRenderer from './PracticeQuestionRenderer.svelte';
  let {block,runId,prefix,houseStyleVersion}= $props();
  // Comparison copies never inherit live editing commands or another block's labels.
  setContext('booklet-labels',()=>({}));
  setContext('booklet-document-actions',null);
  setContext('booklet-presentation',()=>({}));
  const blockFor=mode=>comparisonBlock(block,prefix+mode+'-');
  const modes=$derived(block.type==='question'?['student','short','worked']:['student']);
  const pageFor=mode=>({id:prefix+mode,flexible:true,isCover:false,pageNumber:1,totalPages:1,showTopicHeading:false,showDifficultyHeading:false,section:{headingStyle:'none'},blocks:[blockFor(mode)],mode});
</script>
<div class="shared-block-preview">
  {#each modes as mode}
    {#if modes.length>1}<h5>{mode==='student'?'Question':mode==='short'?'Short answers':'Worked solutions'}</h5>{/if}
    <div class="comparison-paper">
      {#if block.type==='question'}
        <PracticeQuestionRenderer question={blockFor(mode)} showSpaces={false} showShortAnswers={mode==='short'} showWorkedSolutions={mode==='worked'} preserveDiagramWidths={true} eagerDiagrams={true} answerColumnsLimit={1}/>
      {:else}
      <TranscribedBookletPage page={pageFor(mode)} {runId} {houseStyleVersion} flow={true} solutionMode={mode} anchorPrefix={prefix+mode+'-'} showTheorySolutions={true} showKeyIdeasAnswers={true} showReviewAnswers={true} showIdentifyAnswers={true} showGuidedPracticeAnswers={true}/>
      {/if}
    </div>
  {/each}
</div>
<style>
  h5{font:600 13px system-ui;margin:8px 0}
  .comparison-paper{background:white;color:#24282d;padding:10px;border:1px solid #cbd5e1;overflow:auto;min-width:0}
  .comparison-paper :global(.preview-frame){width:100%;height:auto;min-height:0;overflow:visible;margin:0;box-shadow:none}
  .comparison-paper :global(.preview-page){width:100%;position:relative;inset:auto;transform:none}
  .comparison-paper :global(.flow.preview-frame .booklet-page){width:100%;height:auto;min-height:0;padding:0;overflow:visible}
  .comparison-paper :global(.booklet-page main){padding:0}
  .comparison-paper :global(.booklet-footer){display:none}
</style>
