<script>
  import {getProjectSharedComparison} from '../lib/booklet-project-storage.js';
  import SharedBlockPreview from './SharedBlockPreview.svelte';
  // Shared content: blocks that also appear in other booklets. An edit here waits
  // for a decision; updates applied from elsewhere list the pages to check.
  let {project,questionNumbers={},status={members:[],offers:[],checks:[]},titles={},selectedBlockId='',disabled=false,busy=false,onaction=()=>{},onselect=()=>{},onclose=()=>{}}=$props();
  let reasons=$state({}),skipped=$state({});
  let comparison=$state.raw(null),comparisonError=$state(''),loading=$state(false);
  const reviewMember=$derived(pending.find(m=>m.blockId===selectedBlockId)??pending[0]??selected[0]);
  const blockLabel=id=>{
    const section=project.sections.find(s=>s.blocks.some(b=>b.id===id));
    const block=section?.blocks.find(b=>b.id===id);
    const text=[];
    const walk=v=>{if(typeof v==='string')text.push(v);else if(v&&typeof v==='object'){for(const k of ['prompt','text','latex'])if(typeof v[k]==='string')text.push(v[k]);for(const k of ['children','blocks','content','prompt','inlines','rows','cells'])if(v[k]&&typeof v[k]==='object')walk(v[k]);if(Array.isArray(v))v.forEach(walk);}};
    walk(block?.content);
    return [section?.title,questionNumbers[id]?'Question '+questionNumbers[id]:block?.title,(text.join(' ').replace(/<[^>]*>/g,'').replace(/\s+/g,' ').trim()).slice(0,100)].filter(Boolean).join(' — ')||'Shared block';
  };
  $effect(()=>{
    const id=project.id,revision=project.revision,blockId=reviewMember?.blockId;
    // Decisions and refreshed shared status may replace the canonical snapshot.
    void status;
    comparison=null;comparisonError='';loading=!!blockId;
    let active=true;
    if(blockId)getProjectSharedComparison(id,blockId).then(value=>{
      if(active){if(value.revision!==revision)comparisonError='The saved booklet changed. Wait for the booklet to refresh before comparing.';else comparison=value;}
    }).catch(e=>{if(active)comparisonError=e.message;}).finally(()=>{if(active)loading=false;});
    return ()=>{active=false;};
  });
  const offers=$derived(status.offers??[]);
  const targetKey=(blockId,t)=>blockId+'|'+t.projectId+'|'+t.sectionId;
  const chosen=offer=>offer.targets.filter(t=>!skipped[targetKey(offer.blockId,t)]);
  const STATUS={synced:'In step',edited:'Changed here',diverged:'Differs from the other copies',behind:'Update waiting',separate:'Kept different',missing:'Removed'};
  const EDITIONS={student:'Questions',short:'Short answers',worked:'Worked solutions'};
  const title=id=>titles[id]??status.members.flatMap(m=>m.others).find(o=>o.projectId===id)?.title??id??'Unknown booklet';
  const pending=$derived(status.members.filter(m=>m.status==='edited'||m.status==='diverged'));
  const selected=$derived(status.members.filter(m=>m.blockId===selectedBlockId));
  const linkedCopies=m=>m.others.filter(o=>o.status!=='separate').length+1;
  const pages=list=>list.length?(list.length>1?'pages ':'page ')+list.join(', '):'';
  function editionText(edition,r){
    const parts=[];
    if(r.changed.length)parts.push(pages(r.changed)+' changed');
    parts.push(r.moved.length?pages(r.moved)+' moved':'no other pages moved');
    if(r.pageCountChanged)parts.push(`page count ${r.pagesBefore} → ${r.pagesAfter}, so every footer and the contents page changed`);
    return `${EDITIONS[edition]??edition}: ${parts.join('; ')}.`;
  }
</script>

<section class="shared-panel" aria-label="Shared content">
  <header><h2>Shared content</h2><button aria-label="Close shared content" onclick={onclose}>Close</button></header>
  <p>These blocks also appear in other booklets. Applying a change updates every linked copy, keeping each booklet's layout, numbering and skill mapping.</p>
  {#if pending.length}
    <h3>Changes waiting for a decision</h3>
    <nav class="shared-block-list" aria-label="Shared blocks waiting for a decision">
      {#each pending as m (m.groupId+m.blockId)}<button aria-current={reviewMember?.blockId===m.blockId?'true':undefined} onclick={()=>onselect(m.blockId)}>{blockLabel(m.blockId)}<small>{STATUS[m.status]}</small></button>{/each}
    </nav>
  {/if}
  {#if reviewMember}
    {@const m=reviewMember}
    <article class="shared-item">
      <h3>{blockLabel(m.blockId)}</h3>
      <p><strong>{STATUS[m.status]}.</strong> <button class="link" onclick={()=>onselect(m.blockId)}>Go to block</button></p>
      <p>Other copies: {m.others.map(o=>title(o.projectId)+' ('+(STATUS[o.status]??o.status)+')').join(', ')}.</p>
      {#if disabled}<p>Comparison shows saved content. Save or finish the current edit before making a decision.</p>{/if}
      {#if loading}<p role="status">Loading comparison…</p>
      {:else if comparisonError}<p role="alert">{comparisonError}</p>
      {:else if comparison}
        <p>Shared version from {title(comparison.source?.projectId)}.</p>
        <div class="shared-comparison">
          {#each [{label:'This booklet',block:comparison.local,runId:comparison.localRunId},{label:'Shared version',block:comparison.shared,runId:comparison.sharedRunId}] as side,i}
            <section><h4>{side.label}</h4><SharedBlockPreview block={side.block} runId={side.runId} prefix={'shared-compare-'+i+'-'} houseStyleVersion={project.settings.houseStyleVersion}/></section>
          {/each}
        </div>
      {/if}
      {#if m.status==='edited'||m.status==='diverged'}
        {#if m.stale}<p>Another copy changed this content first. Use the shared version, or keep this copy different.</p>{/if}
        <div class="shared-actions">
          {#if !m.stale}<button disabled={disabled||busy||loading||!comparison} onclick={()=>onaction({action:'apply-all',blockId:m.blockId})}>Apply to all {linkedCopies(m)} copies</button>{/if}
          <button disabled={disabled||busy||loading||!comparison} onclick={()=>onaction({action:'use-shared',blockId:m.blockId})}>Use the shared version</button>
          <label>Reason <input aria-label="Reason for keeping this copy different" bind:value={reasons[m.blockId]} placeholder="Optional"/></label>
          <button disabled={disabled||busy} onclick={()=>onaction({action:'keep-separate',blockId:m.blockId,reason:reasons[m.blockId]??''})}>Keep different here</button>
        </div>
      {/if}
    </article>
  {/if}
  {#if offers.length}
    <h3>New questions in shared exercises</h3>
    {#each offers as offer (offer.blockId)}
      <article class="shared-item">
        <p><strong>{offer.excerpt||'New question'}</strong> <button class="link" onclick={()=>onselect(offer.blockId)}>Go to question</button></p>
        <p>Other booklets share this exercise. Add the question to:</p>
        <ul class="shared-targets">{#each offer.targets as t (targetKey(offer.blockId,t))}
          <li><label><input type="checkbox" checked={!skipped[targetKey(offer.blockId,t)]} onchange={e=>skipped[targetKey(offer.blockId,t)]=!e.currentTarget.checked}/> {t.title}{t.sectionTitle?` — ${t.sectionTitle}`:''}</label></li>
        {/each}</ul>
        <div class="shared-actions">
          <button disabled={disabled||busy||!chosen(offer).length} onclick={()=>onaction({action:'offer-add',blockId:offer.blockId,targets:chosen(offer).map(t=>({projectId:t.projectId,sectionId:t.sectionId}))})}>Add to selected booklets</button>
          <button disabled={disabled||busy} onclick={()=>onaction({action:'offer-decline',blockId:offer.blockId})}>Keep in this booklet only</button>
        </div>
      </article>
    {/each}
  {/if}
  {#if status.checks.length}
    <h3>Page reminders after applied updates</h3>
    <p>These changes are already saved in this booklet. Review the listed pages if needed, then dismiss the reminder. Dismissing does not change or publish content.</p>
    {#each status.checks as c (c.id)}
      <article class="shared-item">
        <p>{c.added?'New question':'Update'}{c.from?.projectId?' from '+title(c.from.projectId):''}. <button class="link" onclick={()=>onselect(c.blockId)}>Go to block</button></p>
        {#if c.status==='ready'}{#each Object.entries(c.result??{}) as [edition,r]}<p>{editionText(edition,r)}</p>{/each}
        {:else if c.status==='failed'}<p role="alert">The page check failed: {c.error}</p>
        {:else}<p>Finding the pages that moved…</p>{/if}
        <div class="shared-actions"><button disabled={busy} onclick={()=>onaction({action:'mark-checked',checkId:c.id})}>Dismiss reminder</button></div>
      </article>
    {/each}
  {/if}
  {#if !pending.length&&!offers.length&&!status.checks.length}<p>Nothing is waiting. {status.members.length} shared {status.members.length===1?'block':'blocks'} in this booklet.</p>{/if}

</section>

<style>
  .shared-panel{padding:0 12px 12px;background:var(--panel,#fff);color:var(--text,#24324a)}
  .shared-panel header{position:sticky;top:0;z-index:2;padding:12px 0;background:var(--panel,#fff);display:flex;justify-content:space-between;align-items:center;gap:1rem}
  .shared-panel h2{font-size:1rem;margin:0}.shared-panel h3{font-size:.95rem;margin:1rem 0 .25rem}
  .shared-item{padding:.6rem 0;border-top:1px solid #94a3b8}
  .shared-actions{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center;margin-top:.5rem}
  .shared-targets{list-style:none;padding:0;margin:.25rem 0}
  .link{background:none;border:0;padding:0;color:inherit;text-decoration:underline;cursor:pointer}
  button,input{font:inherit;box-sizing:border-box;min-height:32px;border:1px solid var(--border,#94a3b8);border-radius:5px;padding:6px 8px;background:var(--panel,#fff);color:inherit;max-width:100%}
  button{cursor:pointer}button:disabled{opacity:.45;cursor:default}button:focus-visible,input:focus-visible{outline:3px solid #438ccc;outline-offset:2px}
  .shared-block-list{display:grid;gap:6px;max-height:180px;overflow:auto;padding:3px}.shared-block-list button{text-align:left;overflow-wrap:anywhere}.shared-block-list small{display:block;margin-top:3px}.shared-block-list button[aria-current=true]{border-color:#438ccc;box-shadow:inset 3px 0 #438ccc}
  .shared-comparison{display:grid;grid-template-columns:minmax(0,1fr);gap:12px}.shared-comparison>section{min-width:0}.shared-comparison h4{margin:8px 0}.shared-actions label{display:flex;flex-wrap:wrap;gap:5px;align-items:center}
  @container (min-width:600px){.shared-comparison{grid-template-columns:repeat(2,minmax(0,1fr))}}
</style>
