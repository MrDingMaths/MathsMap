import {verifiedRating,reasoningTaskHash,compatibleRatingHash} from './reasoning-ratings.mjs';
import { promises as fs } from 'node:fs';
import { normalizeProjectLibrary } from '../../src/lib/booklet-library.js';
import { isTheoryReview, isSelectableBankQuestion } from '../../src/lib/question-bank-eligibility.js';
import path from 'node:path';
import {applyBankRatings} from '../../src/lib/booklet-bank-ratings.js';
import {assertBankQuestionDependencies} from '../../src/lib/booklet-question-dependencies.js';
import {supersedeBankQuestion} from './supersede-bank-question.mjs';
import { studioProject, reviewTargets } from '../../src/lib/booklet-review-model.js';
import { mathsMapCandidates } from './assembly-bank.mjs';
import { createHash, randomUUID } from 'node:crypto';
import {captureQuestionPresentation} from '../../src/lib/question-presentation.js';
import {bankProjectionPolicy,projectBankQuestion} from '../../src/lib/question-bank-projection.js';
import {convertToFlexible} from '../../src/lib/booklet-flow.js';
import {withBankLock,prepareAutomaticSync,writeTransaction,registerBankOwner,projectSyncStatus,prepareSyncResolution,syncLinks} from './bank-sync.mjs';
import {refreshBankRatings,sharedHash,questionKeyHash,bankQuestionKeys,linkBlockToBank,secondarySkillAmendment} from './bank-sync.mjs';
import {contentProject} from '../../src/lib/booklet-source-content.js';
import {maintainProjectHistory} from './storage-archive.mjs';
import {preserveSourceLineage} from './source-lineage.mjs';
import {projectCheckpointEntries} from './project-checkpoints.mjs';
import {applyCreationPreset} from '../../src/lib/booklet-creation.js';
import {sharedRootsFor,sharedSaveEntries,sharedStatus,sharedComparison,resolveShared,startPageChecks,scheduleSharedRefresh,refreshIfStale} from './shared-content.mjs';
import {
  WORK_ROOT, REPO_ROOT, applyContentOverrides, hashFile, hashValue, loadRun,
} from './transcription.mjs';
import {
  validateQuestion, makeBankManifest, normaliseForDuplicate,
  normaliseQuestion, questionSearchText,
} from '../../src/lib/practice-question-model.js';
import {
  normalizeTeachingModule, validateTeachingModule,
} from '../../src/lib/teaching-module-model.js';
import {
  createEditableProject, PROJECT_BLOCK_TYPES,
  materializeLegacyProject, normalizeEditableProject, snapshotBankQuestion,
  validateEditableProject,
} from '../../src/lib/editable-booklet-model.js';

const MAX_BODY = 64 * 1024 * 1024;
const PROJECT_ROOT = path.join(REPO_ROOT, 'booklets', 'projects');
const BANK_ROOT = path.join(REPO_ROOT, 'booklets', 'question-bank');
const MODULE_ROOT = path.join(REPO_ROOT, 'booklets', 'module-bank');
const PROJECT_ASSET_ROOT = path.join(REPO_ROOT, 'public', 'booklet-assets', 'projects');

const safeId = (value) => String(value ?? '').replace(/[^a-zA-Z0-9._-]/g, '-').slice(0, 120);
const json = (value) => JSON.stringify(value, null, 2) + '\n';
const send = (res, code, value) => { res.statusCode = code; res.setHeader('Content-Type', 'application/json; charset=utf-8'); res.end(JSON.stringify(value)); };
export const readBody = (req) => new Promise((resolve, reject) => {
  const chunks = []; let bytes = 0;
  req.on('data', (chunk) => { const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk); bytes += buffer.length; if (bytes > MAX_BODY) { reject(new Error('request body too large')); req.destroy(); } else chunks.push(buffer); });
  req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch { reject(new Error('invalid JSON')); } });
  req.on('error', reject);
});

async function readJson(file, fallback = null) {
  try { return JSON.parse(String(await fs.readFile(file, 'utf8')).replace(/^\uFEFF/, '')); } catch { return fallback; }
}

async function writeJson(file, value) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, json(value), 'utf8');
}

function contained(root, value) {
  const base = path.resolve(root);
  const target = path.resolve(value);
  return target === base || target.startsWith(base + path.sep);
}

function fileFor(root, id) {
  const file = path.join(root, `${safeId(id)}.json`);
  if (!contained(root, file)) throw new Error('bad record id');
  return file;
}

function revisionOf(value) {
  return createHash('sha256').update(JSON.stringify(value)).digest('hex');
}

async function readRecords(root) {
  const names = await fs.readdir(root).catch(() => []);
  const files=names.filter((item)=>item.endsWith('.json')&&item!=='manifest.json'),records=new Array(files.length);let cursor=0;
  await Promise.all(Array.from({length:Math.min(32,files.length)},async()=>{
    while(cursor<files.length){const index=cursor++;records[index]=await readJson(path.join(root,files[index]));}
  }));
  return records.filter(Boolean);
}

async function projectLibraries({ bankRoot = BANK_ROOT, moduleRoot = MODULE_ROOT } = {}) {
  return { bank: await readRecords(bankRoot), modules: await readRecords(moduleRoot) };
}

export async function listBookletProjects({ projectRoot = PROJECT_ROOT, summary = false } = {}) {
  const records = await readRecords(projectRoot);
  return records.map((raw) => ({
    id: raw.id,
    title: raw.title ?? 'Untitled booklet',
    subtitle: raw.subtitle ?? '',
    format: raw.format,
    version: raw.version,
    status: raw.status ?? 'draft',
    revision: Number(raw.revision) || 0,
    library: normalizeProjectLibrary(raw.library),
    sections: raw.sections?.length ?? 0,
    updatedAt: raw.updatedAt ?? null,
    ...(!summary?{source:raw.source??null}:{}),
  })).sort((left, right) => String(right.updatedAt ?? '').localeCompare(String(left.updatedAt ?? '')) || left.title.localeCompare(right.title));
}

export async function loadBookletProject(id, options = {}) {
  const projectRoot = options.projectRoot ?? PROJECT_ROOT;
  const raw = await readJson(fileFor(projectRoot, id));
  if (!raw) throw Object.assign(new Error('Booklet project not found'), { statusCode: 404 });
  if (Number(raw.version) === 4) {const project=normalizeEditableProject(raw);return options.refreshRatings===false?project:refreshBankRatings(project,options.bankRoot??BANK_ROOT);}
  const libraries = await projectLibraries(options);
  return materializeLegacyProject(raw, libraries);
}

export async function openBookletProject(id,options={}) {
  let project=await loadBookletProject(id,{...options,refreshRatings:false});
  try{const bankSync=await projectSyncStatus(project,options.bankRoot??BANK_ROOT);project=applyBankRatings(project,bankSync.items);return {project,bankSync,bankSyncError:''};}
  catch(error){return {project,bankSync:{items:[]},bankSyncError:'Could not check bank updates. '+error.message};}
}

async function hydrateBankRevisions(project, bankRoot) {
  const refs = [];
  walk(project.sections, (node) => { if (node?.type === 'question' && node.bankRef?.id && !node.bankRef.revision) refs.push(node); });
  for (const block of refs) {
    const question = await readJson(fileFor(bankRoot, block.bankRef.id));
    if (question) block.bankRef.revision = revisionOf(question);
  }
}

export async function saveBookletProject(raw, options = {}) {
  return withBankLock(()=>saveProjectUnlocked(raw,options));
}
async function saveProjectUnlocked(raw, { projectRoot = PROJECT_ROOT, bankRoot = BANK_ROOT, sharedRoot = sharedRootsFor(projectRoot).sharedRoot, expectedRevision = null, create = false, checkpoint = false } = {}) {
  const checked = validateEditableProject(raw);
  if (!checked.valid) throw Object.assign(new Error(checked.errors.join('; ')), { statusCode: 400 });
  const file = fileFor(projectRoot, checked.project.id);
  const previous = await readJson(file);
  if (create && previous) throw Object.assign(new Error('A project with this id already exists'), { statusCode: 409 });
  if (!create && !previous) throw Object.assign(new Error('Booklet project not found'), { statusCode: 404 });
  if (expectedRevision != null && previous && Number(previous.revision) !== Number(expectedRevision)) {
    throw Object.assign(new Error('Project changed in another session; reload before saving'), { statusCode: 409 });
  }
  const {project,entries,checkpoints}=await prepareProjectWrite(previous,checked.project,{projectRoot,bankRoot,checkpoint,validated:true});
  entries.push(...await sharedSaveEntries(previous,project,{sharedRoot}));
  await writeTransaction(entries);
  if (checkpoints.length) await retainHistory(projectRoot, project.id);
  return project;
}

// The entries of one revision-checked booklet write: the next revision, source
// lineage, bank sync, recovery checkpoint and the project file. Shared-content
// catch-up writes other booklets through this too, so they sync to the bank.
export async function prepareProjectWrite(previous,raw,{projectRoot=PROJECT_ROOT,bankRoot=BANK_ROOT,checkpoint=true,validated=false}={}){
  const checked = validated ? {valid:true,project:raw} : validateEditableProject(raw);
  if (!checked.valid) throw Object.assign(new Error(checked.errors.join('; ')), { statusCode: 400 });
  const now = new Date().toISOString();
  const project = normalizeEditableProject({
    ...checked.project,
    revision: Math.max(0, Number(previous?.revision) || 0) + 1,
    createdAt: previous?.createdAt ?? checked.project.createdAt ?? now,
    updatedAt: now,
  });
  preserveSourceLineage(previous,project,{runDir:project.runId||project.source?.runId?path.join(path.resolve(projectRoot,'../..'),'.booklet-work/full-imports',project.runId??project.source.runId):undefined});
  await hydrateBankRevisions(project, bankRoot);
  const entries=await prepareAutomaticSync(project,bankRoot);
  await refreshBankRatings(project,bankRoot);
  const checkpoints = await projectCheckpointEntries(projectRoot, previous, {force:checkpoint});
  entries.push(...checkpoints,[fileFor(projectRoot,project.id),project]);
  return {project,entries,checkpoints};
}

const sharedOptions=({projectRoot=PROJECT_ROOT,bankRoot=BANK_ROOT,base,busy,...roots}={})=>({projectRoot,...sharedRootsFor(projectRoot),...roots,...(busy?{busy}:{}),
  prepareWrite:(previous,next)=>prepareProjectWrite(previous,next,{projectRoot,bankRoot}),
  onQueued:ids=>{if(base&&ids.length)startPageChecks(ids,{base});}});
export const getProjectSharedComparison=(id,blockId,options={})=>sharedComparison(id,blockId,sharedOptions(options));
export const getProjectShared=(id,options={})=>sharedStatus(id,sharedOptions(options));
export async function resolveProjectShared(id,body,options={}){
  const result=await resolveShared(id,body,sharedOptions(options));
  if(result.project&&options.base)startPageChecks([id],{base:options.base});
  return result;
}

async function retainHistory(projectRoot, id) {
  // The save has committed. Archive trouble must preserve loose recovery files
  // and must not tell the editor that its successful save failed.
  try { await maintainProjectHistory(projectRoot, id); }
  catch (error) { console.warn('Booklet saved; revision archive deferred:', error.message); }
}

export async function getProjectBankSync(id,{projectRoot=PROJECT_ROOT,bankRoot=BANK_ROOT}={}){
  return projectSyncStatus(await loadBookletProject(id,{projectRoot,bankRoot}),bankRoot);
}
export async function resolveProjectBankSync(id,body,{projectRoot=PROJECT_ROOT,bankRoot=BANK_ROOT}={}){
  return withBankLock(async()=>{
    const project=await loadBookletProject(id,{projectRoot,bankRoot});
    if(project.revision!==body.expectedRevision)throw Object.assign(new Error('Booklet changed; reload before applying a bank update.'),{statusCode:409});
    const previous=structuredClone(project),entries=await prepareSyncResolution(project,bankRoot,body);
    const checked=validateEditableProject(project);if(!checked.valid)throw new Error(checked.errors.join('; '));
    project.revision++;project.updatedAt=new Date().toISOString();
    entries.push(...await projectCheckpointEntries(projectRoot,previous,{force:true}),[fileFor(projectRoot,project.id),project]);
    await writeTransaction(entries);await retainHistory(projectRoot, project.id);return project;
  });
}

export async function createBookletProject(raw = {}, options = {}) {
  const project = raw.format || raw.sections
    ? normalizeEditableProject(applyCreationPreset(raw,raw.mode??options.mode??'compact'))
    : createEditableProject({ title: raw.title ?? 'Untitled booklet', subtitle: raw.subtitle ?? '', mode:raw.mode??options.mode??'compact' });
  delete project.mode;
  project.library = normalizeProjectLibrary(raw.library ?? { category: 'master' });
  return saveBookletProject(project, { ...options, create: true });
}

export async function duplicateBookletProject(id, { projectRoot = PROJECT_ROOT, title = null, flexible = false, assignments = {}, copyId = null, library = null, expectedRevision = null, ...options } = {}) {
  const source = await loadBookletProject(id, { projectRoot, ...options });
  if(expectedRevision != null && Number(expectedRevision)!==source.revision) throw Object.assign(new Error('Source booklet changed; reload before copying.'), {statusCode:409});
  let copy = normalizeEditableProject({
    ...source,
    id: copyId ? safeId(copyId) : `project-${randomUUID()}`,
    title: title ?? `${source.title} copy`,
    revision: 0,
    status: 'draft',
    library: normalizeProjectLibrary({...source.library, ...library, archivedAt:null}),
    source: { ...source.source, type: 'project-copy', projectId: source.id, revision: source.revision },
    createdAt: null,
    updatedAt: null,
  });
  if(flexible)copy=convertToFlexible(copy,{linear:source.id==='linear-relationships-complete-v1',assignments});
  // Review comments belong to the source project, not its new class copy.
  if(copy.studio)copy.studio={...copy.studio,flags:[]};
  const links=await syncLinks(options.bankRoot??BANK_ROOT);
  for(const block of copy.sections.flatMap(s=>s.blocks)){
    const match=Object.entries(links).find(([,link])=>link.projectId===source.id&&link.blockId===block.id);
    if(match){block.bankRef={id:match[0],revision:match[1].bankRevision??''};block.canonicalId=match[0];block.snapshotKind='bank';}
  }
  return saveBookletProject(copy, { projectRoot, bankRoot: options.bankRoot, create: true });
}

// Library-only maintenance never publishes pending question changes to the bank.
// It may also rename the booklet; an omitted library keeps the current one.
export async function updateProjectLibrary(id, library, {projectRoot = PROJECT_ROOT, expectedRevision, title, cover} = {}) {
  const nextTitle=title==null?null:String(title).trim();
  if(nextTitle==='')throw Object.assign(new Error('Project needs a title'),{statusCode:400});
  if(cover!=null&&(typeof cover!=='object'||Array.isArray(cover)||Object.entries(cover).some(([key,value])=>!['title','course','book'].includes(key)||typeof value!=='string'||!value.trim())))throw Object.assign(new Error('Cover metadata must contain non-empty title, course or book strings'),{statusCode:400});
  return withBankLock(async()=>{
    const file=fileFor(projectRoot,id), previous=await readJson(file);
    if(!previous)throw Object.assign(new Error('Booklet project not found'),{statusCode:404});
    if(expectedRevision==null || Number(expectedRevision)!==Number(previous.revision))throw Object.assign(new Error('Project changed; reload before updating its library details.'),{statusCode:409});
    const nextLibrary=normalizeProjectLibrary(library??previous.library);
    const renamed=nextTitle!=null&&nextTitle!==previous.title;
    const nextCover=cover==null?previous.settings?.cover:{...previous.settings?.cover,...Object.fromEntries(Object.entries(cover).map(([key,value])=>[key,value.trim()]))};
    const coverChanged=cover!=null&&JSON.stringify(nextCover)!==JSON.stringify(previous.settings?.cover);
    if(!renamed&&!coverChanged&&JSON.stringify(library==null?nextLibrary:previous.library)===JSON.stringify(nextLibrary))return previous;
    const project={...previous,...(renamed?{title:nextTitle}:{}),...(coverChanged?{settings:{...previous.settings,cover:nextCover}}:{}),library:nextLibrary,revision:Number(previous.revision)+1,updatedAt:new Date().toISOString()};
    const checkpoints=await projectCheckpointEntries(projectRoot,previous);
    await writeTransaction([...checkpoints,[file,project]]);
    if(checkpoints.length)await retainHistory(projectRoot,id);
    return project;
  });
}

export async function deleteBookletProject(id, confirmId, { projectRoot = PROJECT_ROOT } = {}) {
  if (!id || confirmId !== id) throw Object.assign(new Error('Exact project id confirmation is required'), { statusCode: 400 });
  const file = fileFor(projectRoot, id);
  await fs.unlink(file).catch((error) => { if (error.code !== 'ENOENT') throw error; });
  return { deleted: id };
}

function walk(value, visit, seen = new Set()) {
  if (!value || typeof value !== 'object' || seen.has(value)) return;
  seen.add(value);
  visit(value);
  for (const child of Object.values(value)) {
    if (Array.isArray(child)) child.forEach((item) => walk(item, visit, seen));
    else if (child && typeof child === 'object') walk(child, visit, seen);
  }
}

async function materializeAssets(project, runDir, { assetRoot = PROJECT_ASSET_ROOT } = {}) {
  const copied = new Map();
  const destinations = [];
  walk(project, (node) => {
    if (typeof node?.src === 'string' && node.src.startsWith('evidence/')) destinations.push(node);
  });
  for (const node of destinations) {
    if (!copied.has(node.src)) {
      const candidates = [path.resolve(runDir, 'lanes', 'exact', node.src), path.resolve(runDir, node.src)];
      if (!candidates.every(file => contained(runDir, file))) throw new Error(`Bad import asset path: ${node.src}`);
      let source;
      for (const file of candidates) { try { if ((await fs.stat(file)).isFile()) { source = file; break; } } catch (error) { if(error.code !== 'ENOENT') throw error; } }
      if (!source) throw new Error(`Missing reconstruction asset: ${node.src}`);
      const digest = hashFile(source).slice(0, 12);
      const name = `${digest}-${safeId(path.basename(source))}`;
      const target = path.join(assetRoot, safeId(project.id), name);
      await fs.mkdir(path.dirname(target), { recursive: true });
      await fs.copyFile(source, target);
      copied.set(node.src, `/booklet-assets/projects/${safeId(project.id)}/${name}`);
    }
    node.src = copied.get(node.src);
  }
  return [...copied.values()];
}

export async function materializeRunAsProject(runId, {
  projectRoot = PROJECT_ROOT, workRoot = WORK_ROOT, assetRoot = PROJECT_ASSET_ROOT,
  candidate = null, projectId = null, mode='compact',
} = {}) {
  if (!candidate || typeof candidate !== 'object') throw new Error('Import requires an explicit candidate; historical run materialization is retired.');
  const { runDir, manifest } = loadRun(runId, workRoot);
  const raw = candidate;
  if ((!Array.isArray(raw.pages) || !raw.pages.length)&&(!Array.isArray(raw.sections)||!raw.sections.length)) throw new Error('Import needs source pages or semantic sections');
  const pageNumbers = new Set();
  for (const page of raw.pages??[]) {
    if (!Number.isInteger(page.pageNumber) || !manifest.selectedPages.includes(page.pageNumber) || pageNumbers.has(page.pageNumber)) throw new Error('Reconstruction has duplicate or unexpected source pages');
    pageNumbers.add(page.pageNumber);
    if (!Array.isArray(page.blocks) || page.blocks.some(block => !PROJECT_BLOCK_TYPES.includes(block.type))) throw new Error('Reconstruction contains unsupported blocks');
  }
  const review = await readJson(path.join(runDir, 'review.json'), {});
  const transcription = applyContentOverrides({...raw, runId:manifest.id}, review);
  const preferredId = projectId ?? `project-${safeId(manifest.id)}-${randomUUID().slice(0,8)}`;
  const existing = await readJson(fileFor(projectRoot, preferredId));
  if (existing) throw Object.assign(new Error('A project with this id already exists'), {statusCode:409});
  const project = studioProject(contentProject(transcription, {runId:manifest.id,review,mode,selectedPages:manifest.selectedPages,projectId:preferredId}));
  project.studio.evidence={runId:manifest.id,answerEvidence:(transcription.pages??[]).flatMap(page=>(page.answerEvidence??[]).map(e=>({...e,studentPage:page.pageNumber}))),sourceReview:review};
  const targets=reviewTargets(project),known=new Set(targets.map(t=>t.id));
  for(const page of transcription.pages??[]){
    const flags=[...(page.reviewFlags??[]).map(note=>({note})),...(review.flags??[]).filter(f=>!f.resolved&&(f.pageNumber===page.pageNumber||f.rootId===page.id||page.blocks.some(b=>b.id===f.rootId)))];
    for(const e of page.answerEvidence??[])if(e.conflict)flags.push({rootId:e.questionId,note:'Student/teacher disagreement: '+e.conflict});
    if(manifest.source?.teacherPdf)for(const block of page.blocks.filter(b=>b.type==='question')){const evidence=(page.answerEvidence??[]).find(e=>e.questionId===block.id);if(!evidence?.teacherReference||evidence.missing||evidence.status==='missing')flags.push({rootId:block.id,note:'Teacher answer alignment is missing or ambiguous; compare by question content against the source.'});}
    for(const f of flags)for(const targetId of known.has(f.rootId)?[f.rootId]:page.blocks.map(b=>b.id))project.studio.flags.push({id:randomUUID(),targetId,note:f.note??f.message??f.code??String(f),sourcePage:page.pageNumber,resolved:false});
  }
  project.source = {
    ...project.source,
    exactResultFormat: manifest.exactResultFormat,
    sourceHashes: { pdf: manifest.source?.pdfHash ?? null, docx: manifest.source?.docxHash ?? null, ...(manifest.source?.teacherPdfHash?{teacherPdf:manifest.source.teacherPdfHash}:{}) },
    referencePages:{context:manifest.contextPages??[],teacher:manifest.teacherPages??[]},
    ...(manifest.source?.teacherPdf?{teacherSource:manifest.source.teacherPdf,teacherHashes:{pdf:manifest.source.teacherPdfHash??manifest.pins?.runFiles?.['source/teacher.pdf'],docx:manifest.source.teacherDocxHash??manifest.pins?.runFiles?.['source/teacher.docx']}}:{}),
    reconstructionHash: hashValue(raw),
    materializedAt: new Date().toISOString(),
  };
  const checked = validateEditableProject(project);
  if (!checked.valid) throw Object.assign(new Error(checked.errors.join('; ')), {statusCode:400});
  project.assets = await materializeAssets(project, runDir, { assetRoot });
  project.source.inventory.selectedPages=manifest.selectedPages;
  return saveBookletProject(project, { projectRoot, create: true });
}

function tokenSimilarity(left, right) {
  const a = new Set(normaliseForDuplicate(left).split(' ').filter(Boolean));
  const b = new Set(normaliseForDuplicate(right).split(' ').filter(Boolean));
  if (!a.size && !b.size) return 1;
  const overlap = [...a].filter((word) => b.has(word)).length;
  return overlap / new Set([...a, ...b]).size;
}

function canonicalFromProjectBlock(block, id) {
  const question = normaliseQuestion({
    id,
    status: 'draft',
    title: block.title ?? '',
    classification: block.classification ?? {},
    content: block.content,
    presentation: block.presentation,
    review: block.review ?? { flags: [], history: [] },
  });
  const ready = validateQuestion(question);
  if (!ready.valid) throw Object.assign(new Error(`Question cannot be published: ${ready.errors.join('; ')}`), { statusCode: 409 });
  return { ...ready.question, status: 'approved', updatedAt: new Date().toISOString() };
}

// Exact and same-question matches use the sync comparison and decide what may be
// created. The similarity list is advisory and built only for the manual dialog.
async function duplicateCandidates(block, bankRoot, projection=bankProjectionPolicy(block), { similar = true } = {}) {
  const shared = sharedHash(block, projection), key = questionKeyHash(block, projection);
  const decided = new Set(block.bankDecision?.of ?? []);
  const matches = (await bankQuestionKeys(bankRoot)).filter((entry) => entry.shared === shared || entry.key === key).map((entry) => ({
    id: entry.id,
    title: entry.title,
    revision: entry.revision,
    exact: entry.shared === shared,
    sameQuestion: true,
    decided: entry.shared !== shared && decided.has(entry.id),
    score: 1,
  })).sort((a, b) => Number(b.exact) - Number(a.exact));
  if (!similar) return matches;
  const local = normaliseQuestion({ ...projectBankQuestion(block,{policy:projection}), id: block.canonicalId ?? block.id });
  const matched = new Set(matches.map((item) => item.id));
  const records = await readRecords(bankRoot);
  return [...matches, ...records.filter((question) => isSelectableBankQuestion(question) && !matched.has(question.id)).map((question) => ({
    id: question.id,
    title: question.title,
    revision: revisionOf(question),
    exact: false,
    sameQuestion: false,
    score: tokenSimilarity(questionSearchText(local), questionSearchText(question)),
  })).filter((item) => item.score >= 0.72).sort((a, b) => b.score - a.score)];
}

async function writeBankManifest(bankRoot) {
  const approved = (await readRecords(bankRoot)).filter((question) => question.status === 'approved').sort((a, b) => a.id.localeCompare(b.id));
  await writeJson(path.join(bankRoot, 'manifest.json'), makeBankManifest(approved));
}

function topLevelQuestion(project, blockId) {
  for (const section of project.sections) {
    const index = section.blocks.findIndex((block) => block.id === blockId && block.type === 'question');
    if (index >= 0) return { section, index, block: section.blocks[index] };
  }
  return null;
}

export async function promoteProjectQuestion(projectId, body = {}, {
  projectRoot = PROJECT_ROOT, bankRoot = BANK_ROOT, moduleRoot = MODULE_ROOT,
} = {}) {
  return withBankLock(()=>promoteQuestionUnlocked(projectId,body,{projectRoot,bankRoot,moduleRoot}));
}
const PROMOTE_MODES = new Set(['inspect', 'link-existing', 'distinct', 'create', 'update']);
async function promoteQuestionUnlocked(projectId,body,{projectRoot,bankRoot,moduleRoot}){
  const mode = body.mode || 'inspect';
  if (!PROMOTE_MODES.has(mode)) throw Object.assign(new Error('Unknown promotion mode'), { statusCode: 400 });
  const project = await loadBookletProject(projectId, { projectRoot, bankRoot, moduleRoot });
  const placement = topLevelQuestion(project, body.blockId);
  if (!placement) throw Object.assign(new Error('Select a top-level project question to promote'), { statusCode: 404 });
  if (isTheoryReview(placement.block, placement.section)) throw Object.assign(new Error('Review questions belong to theory. Save them in a teaching module rather than the practice question bank.'), { statusCode: 400 });
  const link=placement.block.bankRef?.id?(await syncLinks(bankRoot))[placement.block.bankRef.id]:null;
  if(mode==='update'&&body.bankProjection&&(!link||link.projectId!==project.id||link.blockId!==placement.block.id))throw Object.assign(new Error('Projection updates require the existing bank owner'),{statusCode:409});
  const projection=['create','link-existing','update'].includes(mode)?(body.bankProjection??link?.projection??bankProjectionPolicy(placement.block)):link?.projection??bankProjectionPolicy(placement.block);
  const candidates = await duplicateCandidates(placement.block, bankRoot, projection, { similar: mode === 'inspect' });
  if (mode === 'inspect') return { project, candidates };
  assertBankQuestionDependencies(project,{blockIds:[placement.block.id]});
  const match = (id) => candidates.find((item) => item.id === id && item.sameQuestion);
  // Linking to a matching record, or recording a decision, publishes nothing new.
  const publishes = mode === 'create' || mode === 'update' || (mode === 'link-existing' && !match(body.targetId));
  if(path.resolve(bankRoot)===path.resolve(BANK_ROOT)){
   if(project.source?.pipelinePilot)throw Error('Regression pilot content cannot be published to the live bank');
   if(publishes&&(project.source?.workflow??project.source?.inventory?.workflow)?.pipelinePolicy&&!placement.block.bankRef)throw Error('New PDF imports must publish through import-project-bank with the current verification register');
  }

  if (mode === 'distinct') {
    const target = match(body.targetId);
    if (!target) throw Object.assign(new Error('Select a bank question that poses the same question'), { statusCode: 400 });
    if (target.exact) throw Object.assign(new Error('An identical bank question cannot be kept separate. Use the existing question.'), { statusCode: 409 });
    placement.block.bankDecision = { decision: 'distinct', of: [...new Set([...(placement.block.bankDecision?.of ?? []), target.id])] };
    const saved = await saveProjectUnlocked(project, { projectRoot, bankRoot, expectedRevision: project.revision });
    return { project: saved, candidates };
  }

  if (mode === 'link-existing') {
    const target = await readJson(fileFor(bankRoot, body.targetId));
    if (!target) throw Object.assign(new Error('The selected bank question no longer exists'), { statusCode: 404 });
    if (!isSelectableBankQuestion(target)) throw Object.assign(new Error('This question is not available in the practice question bank.'), { statusCode: 400 });
    if (match(target.id)) {
      // The booklet's own block stays: identity for an exact match, the bank's answers otherwise.
      const amendment = await secondarySkillAmendment(bankRoot, target, placement.block.classification?.primarySkillId);
      if (amendment) await writeTransaction(amendment.entries);
      linkBlockToBank(project, placement.block, amendment?.bank ?? target,projection);
    } else placement.section.blocks[placement.index] = snapshotBankQuestion(target, { placementId: placement.block.id });
    const saved = await saveProjectUnlocked(project, { projectRoot, bankRoot, expectedRevision: project.revision });
    return { project: saved, question: target, candidates };
  }

  if (mode === 'create') {
    const exact = candidates.find((item) => item.exact), undecided = candidates.find((item) => item.sameQuestion && !item.exact && !item.decided);
    if (exact) throw Object.assign(new Error('This question is identical to bank question ' + exact.id + '. Use the existing question.'), { statusCode: 409 });
    if (undecided) throw Object.assign(new Error('Bank question ' + undecided.id + ' poses the same question with a different answer. Choose Use existing or Keep separate first.'), { statusCode: 409 });
  }

  const targetId = mode === 'update'
    ? String(placement.block.bankRef?.id ?? body.targetId ?? '')
    : `q-${randomUUID()}`;
  if (!targetId) throw Object.assign(new Error('Updating the bank requires an existing bank reference'), { statusCode: 400 });
  const file = fileFor(bankRoot, targetId);
  const previous = await readJson(file);
  if (mode === 'create' && previous) throw Object.assign(new Error('Question id already exists'), { statusCode: 409 });
  if (mode === 'update' && !previous) throw Object.assign(new Error('Referenced bank question no longer exists'), { statusCode: 404 });
  const reviewedBlock=JSON.parse(JSON.stringify(placement.block));
  reviewedBlock.presentation=captureQuestionPresentation(placement.block,project.settings?.layoutOverrides);
  placement.block.presentation=reviewedBlock.presentation;
  const mapping=project.studio?.atoms?.[placement.block.id];
  if(!reviewedBlock.classification?.primarySkillId && mapping?.skillIds?.length)reviewedBlock.classification={...reviewedBlock.classification,primarySkillId:mapping.skillIds[0],secondarySkillIds:mapping.skillIds.slice(1),archetype:mapping.archetype};
  const attach=node=>{if(!node)return;const atom=project.studio?.atoms?.[node.id];if(atom)node.teachingMapping=atom;(node.children??[]).forEach(attach);};attach(reviewedBlock.content);
  const publicationProjection=mode==='create'||mode==='update'&&body.bankProjection?projection:link?.projection??null;
  let approved = canonicalFromProjectBlock(projectBankQuestion(reviewedBlock,{policy:publicationProjection}), targetId);
  if(mode==='update'&&body.bankProjection){
    if(compatibleRatingHash(previous)!==compatibleRatingHash(projectBankQuestion(reviewedBlock,{policy:link?.projection??null})))throw Object.assign(new Error('Projection updates must preserve the existing mathematical task'),{statusCode:409});
    approved={...structuredClone(previous),content:approved.content,presentation:approved.presentation,updatedAt:approved.updatedAt};
  }
  if(publicationProjection&&!publicationProjection.prependPromptBlocks?.length&&verifiedRating(reviewedBlock)&&approved.classification.assessment?.taskHash!==reasoningTaskHash(approved)){
    approved.classification.assessment={...approved.classification.assessment,originalTaskHash:approved.classification.assessment.originalTaskHash??approved.classification.assessment.taskHash,taskHash:reasoningTaskHash(approved),equivalentProjection:{version:1,policyHash:revisionOf(publicationProjection)}};
  }
  if (previous) await writeJson(path.join(bankRoot, '.revisions', safeId(targetId), `${revisionOf(previous)}.json`), previous);
  await writeJson(file, approved);
  await writeBankManifest(bankRoot);
  placement.block.bankRef = { id: approved.id, revision: revisionOf(approved) };
  placement.block.canonicalId = approved.id;
  placement.block.snapshotKind = 'bank';
  const saved = await saveProjectUnlocked(project, { projectRoot, bankRoot, expectedRevision: project.revision });
  if(mode==='create'||mode==='update'&&body.bankProjection)await registerBankOwner(bankRoot,saved,placement.block,approved,publicationProjection,{refreshExisting:mode==='update'});
  return { project: saved, question: approved, candidates };
}

export async function promoteProjectModule(projectId, body = {}, {
  projectRoot = PROJECT_ROOT, bankRoot = BANK_ROOT, moduleRoot = MODULE_ROOT,
} = {}) {
  const project = await loadBookletProject(projectId, { projectRoot, bankRoot, moduleRoot });
  const section = project.sections.find((item) => item.id === body.sectionId);
  if (!section) throw Object.assign(new Error('Project section not found'), { statusCode: 404 });
  const wanted = new Set(body.blockIds?.length ? body.blockIds : section.blocks.map((block) => block.id));
  const selected = section.blocks.filter((block) => wanted.has(block.id));
  if (!selected.length) throw Object.assign(new Error('Select at least one block for the teaching module'), { statusCode: 400 });
  const sequence = selected.map((block) => {
    if (block.type === 'question' && isTheoryReview(block, section)) return { type: 'content-block', id: `module-item-${block.id}`, pedagogyRole: 'theory', block: {...block, libraryRole:'theory-review', bankRef:null, snapshotKind:'local', presentation:captureQuestionPresentation(block,project.settings?.layoutOverrides)} };
    if (block.type !== 'question') return { type: 'content-block', id: `module-item-${block.id}`, pedagogyRole: block.pedagogyRole ?? (block.type === 'worked-example' ? 'worked-example' : 'theory'), block:{...block,presentation:captureQuestionPresentation(block,project.settings?.layoutOverrides)} };
    if (!block.bankRef?.id) throw Object.assign(new Error(`Question ${block.id} must be promoted before it can enter a reusable module`), { statusCode: 409 });
    return { type: 'question-ref', id: `module-ref-${block.id}`, questionId: block.bankRef.id, questionRevision: block.bankRef.revision, snapshot: normaliseQuestion({...block,id:block.bankRef.id}), pedagogyRole: block.pedagogyRole ?? 'guided-practice', order: 'fixed' };
  });
  const module = normalizeTeachingModule({
    status: 'approved',
    id: body.id ?? `module-${randomUUID()}`,
    title: body.title ?? section.title,
    classification: body.classification ?? { mappingStatus: 'unmapped' },
    sequence,
    review: { flags: [], history: [] },
  });
  const checked = validateTeachingModule(module);
  if (!checked.valid) throw Object.assign(new Error(checked.errors.join('; ')), { statusCode: 400 });
  await writeJson(fileFor(moduleRoot, module.id), module);
  return { module };
}

export function projectStudioPlugin() {
  return {
    name: 'booklet-project-studio',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const pathname = new URL(req.url ?? '/', 'http://localhost').pathname;
        if (!pathname.startsWith('/__booklet/projects')) return next();
        try {
          if (pathname === '/__booklet/projects/assembly-bank' && req.method === 'GET') return send(res, 200, { candidates: await mathsMapCandidates((new URL(req.url,'http://localhost').searchParams.get('skills') ?? '').split(',').filter(Boolean)) });
          if (pathname === '/__booklet/projects' && req.method === 'GET') return send(res, 200, await listBookletProjects({summary:new URL(req.url,'http://localhost').searchParams.get('summary')==='1'}));
          if (pathname === '/__booklet/projects' && req.method === 'POST') return send(res, 201, await createBookletProject(await readBody(req)));
          const libraryMatch=pathname.match(/^\/__booklet\/projects\/([^/]+)\/library$/);
          if(libraryMatch&&req.method==='PATCH'){
            const body=await readBody(req);
            return send(res,200,await updateProjectLibrary(decodeURIComponent(libraryMatch[1]),body.library,{expectedRevision:body.expectedRevision,title:body.title,cover:body.cover}));
          }
          const openMatch=pathname.match(/^\/__booklet\/projects\/([^/]+)\/open$/);
          if(openMatch&&req.method==='GET')return send(res,200,await openBookletProject(decodeURIComponent(openMatch[1])));
          const duplicateMatch = pathname.match(/^\/__booklet\/projects\/([^/]+)\/duplicate$/);
          if (duplicateMatch && req.method === 'POST') return send(res, 201, await duplicateBookletProject(decodeURIComponent(duplicateMatch[1]), await readBody(req)));
          const promoteMatch = pathname.match(/^\/__booklet\/projects\/([^/]+)\/promote-question$/);
          if (promoteMatch && req.method === 'POST') return send(res, 200, await promoteProjectQuestion(decodeURIComponent(promoteMatch[1]), await readBody(req)));
          const moduleMatch = pathname.match(/^\/__booklet\/projects\/([^/]+)\/promote-module$/);
          if (moduleMatch && req.method === 'POST') return send(res, 200, await promoteProjectModule(decodeURIComponent(moduleMatch[1]), await readBody(req)));
          const supersedeMatch = pathname.match(/^\/__booklet\/projects\/([^/]+)\/supersede-bank-question$/);
          if(supersedeMatch&&req.method==='POST'){const body=await readBody(req);if(body.projectId!==decodeURIComponent(supersedeMatch[1]))throw Object.assign(new Error('Supersession project does not match'),{statusCode:400});return send(res,200,await supersedeBankQuestion(body));}
          const projectMatch = pathname.match(/^\/__booklet\/projects\/([^/]+)$/);
          const syncMatch = pathname.match(/^\/__booklet\/projects\/([^/]+)\/bank-sync$/);
          if(syncMatch&&req.method==='GET')return send(res,200,await getProjectBankSync(decodeURIComponent(syncMatch[1])));
          if(syncMatch&&req.method==='POST')return send(res,200,await resolveProjectBankSync(decodeURIComponent(syncMatch[1]),await readBody(req)));
          const sharedComparisonMatch=pathname.match(/^\/__booklet\/projects\/([^/]+)\/shared\/comparison$/);
          if(sharedComparisonMatch&&req.method==='GET')return send(res,200,await getProjectSharedComparison(decodeURIComponent(sharedComparisonMatch[1]),new URL(req.url,'http://localhost').searchParams.get('blockId')));
          const sharedMatch = pathname.match(/^\/__booklet\/projects\/([^/]+)\/shared$/);
          // The shared-content registry follows the library by itself: shortly after
          // each save or decision, and on a status check when a minute has passed.
          if(sharedMatch&&req.method==='GET'){refreshIfStale();return send(res,200,await getProjectShared(decodeURIComponent(sharedMatch[1])));}
          if(sharedMatch&&req.method==='POST'){const url=server.resolvedUrls?.local?.[0];const result=await resolveProjectShared(decodeURIComponent(sharedMatch[1]),await readBody(req),{base:url?url.replace(/\/$/,''):'http://127.0.0.1:'+(server.config.server.port??5173)});scheduleSharedRefresh();return send(res,200,result);}
          if (projectMatch && req.method === 'GET') return send(res, 200, await loadBookletProject(decodeURIComponent(projectMatch[1])));
          if (projectMatch && req.method === 'PUT') {
            const body = await readBody(req);
            const saved = await saveBookletProject(body.project ?? body, { expectedRevision: body.expectedRevision ?? body.project?.revision });
            scheduleSharedRefresh();
            return send(res, 200, saved);
          }
          if (projectMatch && req.method === 'DELETE') {
            const body = await readBody(req);
            return send(res, 200, await deleteBookletProject(decodeURIComponent(projectMatch[1]), body.confirmId));
          }
          return send(res, 404, { error: 'Booklet project endpoint not found.' });
        } catch (error) { return send(res, error.statusCode ?? 500, { error: error.message }); }
      });
    },
  };
}
